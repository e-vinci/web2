# Consignes
- Renommer le répertoire **examen_js** en **NOM_PRENOM**
- Pour chaque question, utilisez le boilerplate offert. 
Vous allez devoir installer les packages pour faire fonctionner vos applications.
N'hésitez pas à modifier ou ajouter tous les fichiers JS nécessaires.

# Resources
- Toutes les blagues (en anglais) proviennent de cette API : https://v2.jokeapi.dev/
- Image de la catégorie "Pun" de Walmart : https://www.walmart.com/ip/Pun-Intended-2022-Box-Calendar-Daily-Pun-Humor-Desktop-Other-9781549220623/761629971
- Image de la catégore "Programming" de Twitter : https://javascript.plainenglish.io/20-programming-jokes-you-can-understand-even-if-you-are-not-a-programmer-14da6bf860e
- Image de la catégorie "Christmas" de TheHolidaySpot : https://www.theholidayspot.com/christmas/jokes/
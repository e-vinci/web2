# Consignes
- Renommer le répertoire **examen_js** en **NOM_PRENOM**
- Pour chaque question, utilisez le boilerplate offert. 
Vous allez devoir installer les packages pour faire fonctionner vos applications.
N'hésitez pas à modifier ou ajouter tous les fichiers JS nécessaires.
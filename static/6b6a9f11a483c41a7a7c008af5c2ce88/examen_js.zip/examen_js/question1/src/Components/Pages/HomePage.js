/**
 * Render the HomePage
 */

const HomePage = () => { 
  const pageDiv = document.querySelector("#page");
  pageDiv.innerHTML = "Deal with the content of your HomePage";
};

export default HomePage;
